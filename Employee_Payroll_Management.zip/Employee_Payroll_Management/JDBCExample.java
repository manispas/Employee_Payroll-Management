import java.sql.*;
public class JDBCExample {
    
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl"; // "jdbc:oracle:thin:@//localhost:1521/orcl"
    private static final String USER = "system";
    private static final String PASS = "Anshul@12345";

    public static void main(String[] args) throws Exception{
        
        // Declare a Connection object
        Connection conn = null;
        
        try {
            // Step 1: Register Oracle JDBC driver
            Class.forName("oracle.jdbc.OracleDriver");
            
            // Step 2: Open a connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            
            // Step 3: Create a statement and execute a query
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM employee";
            ResultSet rs = stmt.executeQuery(sql);

            // Step 4: Process the result set
            while (rs.next()) {
                int id = rs.getInt("emp_id"); // Assuming the column name is "id"
                String name = rs.getString("emp_fname"); // Assuming the column name is "name"
                System.out.println("ID: " + id + ", Name: " + name);
                
            }

            
            // String sql = "INSERT INTO employee (emp_id, emp_fname, emp_lname, designation, dept, joining_date, salary) VALUES (1, 'John', 'Doe', 'Software Engineer', 'IT', TO_DATE('2022-01-15', 'YYYY-MM-DD'), 75000)";

            // int rowsAffected = stmt.executeUpdate(sql);
            
            // // Step 4: Check if the query was successful
            // if (rowsAffected > 0) {
            //     System.out.println("Employee added successfully.");
            // } else {
            //     System.out.println("Failed to add employee.");
            // }
            
            // Step 5: Clean-up environment
            // rs.close();
            stmt.close();
        } catch (SQLException se) {
            // Handle JDBC errors
            se.printStackTrace();
        } catch (Exception e) {
            // Handle Class.forName errors
            e.printStackTrace();
        } finally {
            // Finally, close the connection
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
