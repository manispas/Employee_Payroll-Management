CREATE TABLE view_leave_requests (
    emp_ID NUMBER NOT NULL,          -- Employee ID
    name VARCHAR2(50),             -- Employee Name
    department VARCHAR2(50),       -- Department Name
    leave_date DATE,                -- Date of Leave
    reason VARCHAR2(50),           -- Reason for Leave
    type VARCHAR2(50),              -- Type of Leave (e.g., sick, vacation)
    status VARCHAR2(50)           -- Status (e.g., pending, approved, rejected)
);

INSERT INTO view_leave_requests (emp_ID, name, department, leave_date, reason, type, status)
VALUES (67890, 'Manish Kumar', 'Support', TO_DATE('2024-11-20', 'YYYY-MM-DD'), 'Medical Emergency', 'Sick Leave', 'Pending');

INSERT INTO view_leave_requests (emp_ID, name, department, leave_date, reason, type, status)
VALUES (10001, 'Abhinav Singh', 'AT Mobile', TO_DATE('2024-11-30', 'YYYY-MM-DD'), 'Vacation', 'Other Leave', 'Pending');

INSERT INTO view_leave_requests (emp_ID, name, department, leave_date, reason, type, status)
VALUES (12345, 'Arham Jain', 'PSU BSS', TO_DATE('2024-11-30', 'YYYY-MM-DD'), 'Medical Emergency', 'Sick Leave', 'Pending');

INSERT INTO view_leave_requests (emp_ID, name, department, leave_date, reason, type, status)
VALUES (12345, 'Arham Jain', 'PSU BSS', TO_DATE('2024-11-29', 'YYYY-MM-DD'), 'Vacation', 'Casual Leave', 'Pending');
commit;

CREATE TABLE attendance_table1 (
    date DATE NOT NULL,             -- The date of attendance
    status VARCHAR2(20) NOT NULL,   -- Attendance status (e.g., Present, Absent)
    clockin TIMESTAMP,              -- Clock-in time
    clockout TIMESTAMP,             -- Clock-out time
    hours_worked INTERVAL DAY TO SECOND -- Hours worked (duration)
);







