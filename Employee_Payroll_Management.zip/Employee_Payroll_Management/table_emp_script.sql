CREATE TABLE employee (
    emp_id NUMBER(10) PRIMARY KEY,      -- Employee ID (Primary Key)
    emp_fname VARCHAR2(15) NOT NULL,    -- Employee First Name (Mandatory)
    emp_lname VARCHAR2(10) NOT NULL,    -- Employee Last Name (Mandatory)
    designation VARCHAR2(150) NOT NULL, -- Employee Designation
    dept VARCHAR2(100) NOT NULL,        -- Employee Department
    joining_date DATE NOT NULL,         -- Joining Date (Mandatory)
    salary NUMBER(10, 2) NOT NULL       -- Salary (with two decimal places)
);

INSERT INTO employee (employee_id, first_name, last_name, designation, department, joining_date, salary)
VALUES (1, 'John', 'Doe', 'Software Engineer', 'IT', TO_DATE('2022-01-15', 'YYYY-MM-DD'), 75000.00);

INSERT INTO employee (employee_id, first_name, last_name, designation, department, joining_date, salary)
VALUES (2, 'Jane', 'Smith', 'HR Manager', 'Human Resources', TO_DATE('2021-07-01', 'YYYY-MM-DD'), 85000.00);

INSERT INTO employee (employee_id, first_name, last_name, designation, department, joining_date, salary)
VALUES (3, 'Emily', 'Johnson', 'Database Administrator', 'IT', TO_DATE('2020-10-10', 'YYYY-MM-DD'), 95000.00);

SELECT * FROM employee;