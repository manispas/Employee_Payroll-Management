package payroll.src.main;

import payroll.src.main.utils.UI;
import payroll.src.main.admin.DatabaseAdmin;
import payroll.src.main.admin.HrAdmin;

import payroll.src.main.user.EmployeeSystem;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UI.displayHeader();
        UI.displayWelcomeMessage();
        while (true) {
         
            UI.displayRoleMenu();

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        DatabaseAdmin.handleLogin(scanner); // Navigate to Database Admin section
                        break;
                    case 2:
                        HrAdmin.handleLogin(scanner);
                        break;
                    case 3:
                        EmployeeSystem.handleLogin(scanner);
                        break;
                    case 4:
                        System.out.println("\nExiting the application. Goodbye!\n");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid input! Please select a valid option (1-4).");
                }
            } catch (NumberFormatException e) {
                // System.out.println("hello");
                System.out.println("\nInvalid input! Please enter a number (1-5).\n");
            }
        }
    }
}