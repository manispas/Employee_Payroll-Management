package payroll.src.main.user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import payroll.src.main.user.EmployeeSystem;

public class AM {

    // Method to check if the given date is a weekend (Saturday or Sunday)
    private static boolean isWeekend(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        return (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY);
    }

    // Method to get the working and holiday days of the current month and display
    // in a table
    private static void displayWorkingDaysAndHolidays() {
        Calendar calendar = Calendar.getInstance();
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        System.out.println("====================================================================");
        System.out.println("               WORKING DAYS AND HOLIDAYS FOR NOVEMBER            ");
        System.out.println("====================================================================");
        System.out.println("+------------------+------------------+");
        System.out.println("| Date             | Day Type         |");
        System.out.println("+------------------+------------------+");

        for (int i = 1; i <= daysInMonth; i++) {
            calendar.set(Calendar.DAY_OF_MONTH, i);
            Date date = calendar.getTime();
            String dayType = isWeekend(date) ? "Holiday" : "Working Day";
            String formattedDate = new SimpleDateFormat("dd MMM yyyy").format(date);
            System.out.printf("| %-16s | %-16s |\n", formattedDate, dayType);
        }

        System.out.println("+------------------+------------------+");
    }

    // Method to allow user to mark attendance
    private static void markAttendance(Scanner scanner, List<Long> workedHours) {
        Calendar today = Calendar.getInstance();
        Date currentDate = today.getTime();
        Date enteredDate = null;
        boolean validDate = false;

        while (!validDate) {
            System.out.print("\nEnter the date (dd-mm-yyyy) to mark attendance: ");
            String inputDate = scanner.nextLine();

            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                dateFormat.setLenient(false);
                enteredDate = dateFormat.parse(inputDate);

                Calendar enteredCalendar = Calendar.getInstance();
                enteredCalendar.setTime(enteredDate);

                // Validation checks
                if (enteredDate.after(currentDate)) {
                    System.out.println("Error: You cannot mark attendance for a future date.");
                } else if (enteredCalendar.get(Calendar.YEAR) < today.get(Calendar.YEAR) ||
                        (enteredCalendar.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                                enteredCalendar.get(Calendar.MONTH) < today.get(Calendar.MONTH))) {
                    System.out.println("Error: Attendance cannot be marked for dates in previous months.");
                } else if (isWeekend(enteredDate)) {
                    System.out.println("Error: Attendance cannot be marked for weekends (Saturday/Sunday).");
                } else {
                    validDate = true;
                }
            } catch (ParseException e) {
                System.out
                        .println("Error: Invalid date! Please ensure the date exists and is in 'dd-MM-yyyy' format.");
            }
        }

        String status = "";
        while (true) {
            System.out.print("\nEnter attendance status (P for Present, A for Absent): ");
            status = scanner.nextLine().toUpperCase();
            if (status.equals("P") || status.equals("A")) {
                break;
            } else {
                System.out.println("Error: Invalid status. Please enter 'P' for Present or 'A' for Absent.");
            }
        }

        if (status.equals("P")) {
            markPresent(scanner, workedHours);
        } else {
            System.out.println("Attendance marked as Absent.");
        }
    }

    // Method to handle present attendance with clock-in and clock-out times
    private static void markPresent(Scanner scanner, List<Long> workedHours) {
        String clockInTime = "";
        String clockOutTime = "";

        while (true) {
            try {
                System.out.println("Please use 24 HR Format only (00:00-24:00)");
                System.out.print("\nEnter Clock-in time (HH:MM): ");
                clockInTime = scanner.nextLine();
                System.out.print("Enter Clock-out time (HH:MM): ");
                clockOutTime = scanner.nextLine();

                if (validateTimeFormat(clockInTime) && validateTimeFormat(clockOutTime)) {
                    long hoursWorked = calculateWorkedHours(clockInTime, clockOutTime);

                    // Validate Clock-out > Clock-in and minimum 2 hours
                    if (hoursWorked < 2) {
                        throw new IllegalArgumentException(
                                "Clock-out time must be at least 2 hours after Clock-in time.");
                    }

                    workedHours.add(hoursWorked);
                    System.out.println("Attendance marked as Present.");
                    System.out.println("   Clock-in: " + clockInTime + ", Clock-out: " + clockOutTime);
                    System.out.println("   Hours Worked: " + hoursWorked + " hours");
                    break;
                } else {
                    throw new IllegalArgumentException("Invalid time format.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage() + " Please try again.");
            }
        }
    }

    // Method to validate time format (HH:mm)
    private static boolean validateTimeFormat(String time) {
        String timePattern = "([01]?[0-9]|2[0-3]):([0-5][0-9])";
        return time.matches(timePattern);
    }

    // Method to calculate worked hours between clock-in and clock-out times
    private static long calculateWorkedHours(String clockInTime, String clockOutTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            Date clockIn = sdf.parse(clockInTime);
            Date clockOut = sdf.parse(clockOutTime);

            long differenceInMillis = clockOut.getTime() - clockIn.getTime();
            return differenceInMillis / (1000 * 60 * 60);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Error calculating hours.");
        }
    }

    public static void AttendanceManagement(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Long> workedHours = new ArrayList<>();
        String userChoice = "Y";

        System.out.println("====================================================================");
        System.out.println("               WELCOME TO THE ATTENDANCE SYSTEM (AMDOCS)          ");
        System.out.println("====================================================================");

        displayWorkingDaysAndHolidays();

        do {
            markAttendance(scanner, workedHours);

            while (true) {
                System.out.print("\nDo you want to mark attendance for another day? (Y for Yes, N for No): ");
                userChoice = scanner.nextLine().toUpperCase();
                if (userChoice.equals("Y") || userChoice.equals("N")) {
                    break;
                } else {
                    System.out.println("Error: Invalid choice. Please enter 'Y' for Yes or 'N' for No.");
                }
            }
        } while (userChoice.equals("Y"));

        long totalWorkedHours = workedHours.stream().mapToLong(Long::longValue).sum();

        System.out.println("\n=================================================================");
        System.out.println("            TOTAL HOURS WORKED: " + totalWorkedHours + " HOURS             ");
        System.out.println("=================================================================");
        System.out.println("Thank you for using the Attendance Management System. Goodbye!");
        System.out.println("=================================================================");
        EmployeeSystem.showUserAdminMenu(scanner);
    }
}
