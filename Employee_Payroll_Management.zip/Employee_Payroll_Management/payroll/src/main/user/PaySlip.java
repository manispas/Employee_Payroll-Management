package payroll.src.main.user;

import java.util.HashMap;
import java.util.Map;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Scanner;
import payroll.src.main.user.EmployeeSystem;

class Employee {
    private int id;
    private String name;
    private String department;
    private double ctc;
    private double basicSalary;
    private double hra;
    private double otherAllowances;
    private double deductions;
    private double bonus;
    private double incentives;
    private double tds;
    private double otherTaxes;

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getCtc() {
        return ctc;
    }

    public void setCtc(double ctc) {
        this.ctc = ctc;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getHra() {
        return hra;
    }

    public void setHra(double hra) {
        this.hra = hra;
    }

    public double getOtherAllowances() {
        return otherAllowances;
    }

    public void setOtherAllowances(double otherAllowances) {
        this.otherAllowances = otherAllowances;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double getIncentives() {
        return incentives;
    }

    public void setIncentives(double incentives) {
        this.incentives = incentives;
    }

    public double getTds() {
        return tds;
    }

    public void setTds(double tds) {
        this.tds = tds;
    }

    public double getOtherTaxes() {
        return otherTaxes;
    }

    public void setOtherTaxes(double otherTaxes) {
        this.otherTaxes = otherTaxes;
    }
}

class PayrollSystem {
    private Map<Integer, Employee> employeeData;

    public PayrollSystem() {
        employeeData = new HashMap<>();
        loadDummyData();
    }

    private void loadDummyData() {
        Employee emp1 = new Employee();
        emp1.setId(12345);
        emp1.setName("Arham Jain");
        emp1.setDepartment("PSU BSS");
        emp1.setCtc(650_000.00);
        emp1.setBasicSalary(250_000.00 / 12);
        emp1.setHra(250_000.00 / 12);
        emp1.setOtherAllowances(100_000.00 / 12);
        emp1.setDeductions(50_000.00 / 12);
        emp1.setBonus(25_000.00 / 12);
        emp1.setIncentives(25_000.00 / 12);
        emp1.setTds(emp1.getBasicSalary() * 0.13);
        emp1.setOtherTaxes(emp1.getBasicSalary() * 0.07);
 
        Employee emp2 = new Employee();
        emp2.setId(67890);
        emp2.setName("Abhinav Singh");
        emp2.setDepartment("TEST ENGG");
        emp2.setCtc(650_000.00);
        emp2.setBasicSalary(250_000.00 / 12);
        emp2.setHra(250_000.00 / 12);
        emp2.setOtherAllowances(100_000.00 / 12);
        emp2.setDeductions(30_000.00 / 12);
        emp2.setBonus(25_000.00 / 12);
        emp2.setIncentives(25_000.00 / 12);
        emp2.setTds(emp2.getBasicSalary() * 0.13);
        emp2.setOtherTaxes(emp2.getBasicSalary() * 0.07);
 
        employeeData.put(emp1.getId(), emp1);
        employeeData.put(emp2.getId(), emp2);

    }

    public void showPayslip(int employeeId, int months) {
        Employee employee = employeeData.get(employeeId);
        if (employee != null) {
            Calendar calendar = Calendar.getInstance();
            String[] monthNames = { "January", "February", "March", "April", "May", "June", "July", "August",
                    "September", "October", "November", "December" };

            for (int i = 0; i < months; i++) {
                int monthIndex = (calendar.get(Calendar.MONTH) - i - 1 + 12) % 12;
                String monthName = monthNames[monthIndex];

                double totalSalaryCredited = employee.getBasicSalary() + employee.getHra()
                        + employee.getOtherAllowances() + employee.getBonus() + employee.getIncentives()
                        - employee.getDeductions() - employee.getTds() - employee.getOtherTaxes();

                System.out.println("*********************************************");
                System.out.println("*                                           *");
                System.out.println("*               PAYSLIP                     *");
                System.out.println("*                                           *");
                System.out.println("*********************************************");
                System.out.println("Month: " + monthName);
                System.out.println("---------------------------------------------");
                System.out.printf("| %-20s : %15s |\n", "Name", employee.getName());
                System.out.printf("| %-20s : %15s |\n", "Department", employee.getDepartment());
                System.out.println("---------------------------------------------");
                System.out.printf("| %-20s : %,15.2f |\n", "CTC", employee.getCtc());
                System.out.println("---------------------------------------------");
                System.out.printf("| %-20s : %,15.2f |\n", "Basic Salary", employee.getBasicSalary());
                System.out.printf("| %-20s : %,15.2f |\n", "HRA", employee.getHra());
                System.out.printf("| %-20s : %,15.2f |\n", "Other Allowances", employee.getOtherAllowances());
                System.out.printf("| %-20s : %,15.2f |\n", "Deductions", employee.getDeductions());
                System.out.printf("| %-20s : %,15.2f |\n", "Bonus", employee.getBonus());
                System.out.printf("| %-20s : %,15.2f |\n", "Incentives", employee.getIncentives());
                System.out.println("| TAX                  :                     |");
                System.out.printf("|   %-18s : %,15.2f |\n", "TDS (13%)", employee.getTds());
                System.out.printf("|   %-18s : %,15.2f |\n", "Other Taxes (7%)", employee.getOtherTaxes());
                System.out.println("---------------------------------------------");
                System.out.printf("| %-20s : %,15.2f |\n", "Total Salary Credited", totalSalaryCredited);
                System.out.println("---------------------------------------------");
            }
        } else {
            System.out.println("Employee not found.");
        }
    }
}

public class PaySlip {
    public static void ViewPaySlip(String[] args, Scanner scanner) {
        PayrollSystem payrollSystem = new PayrollSystem();
        boolean exit = false;

        while (!exit) {
            try {
                System.out.println("\nSelect option:");
                System.out.println("1. Show last month's payslip");
                System.out.println("2. Show last 3 months' payslip");
                System.out.println("3. Exit");
                System.out.print("Enter your choice: ");
                int option = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (option) {
                    case 1:
                        payrollSystem.showPayslip(12345, 1); // Dummy employee ID for demonstration
                        break;
                    case 2:
                        payrollSystem.showPayslip(12345, 3); // Dummy employee ID for demonstration
                        break;
                    case 3:
                        EmployeeSystem.showUserAdminMenu(scanner);
                        exit = true;// Exit from this menu
                        break;
                    default:
                        System.out.println("Invalid option selected. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Consume invalid input
            }
        }

        // Returning to main user menu

    }

    private static void logout() {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("Kindly please log in.");
        System.out.println("=".repeat(40));
    }
}
