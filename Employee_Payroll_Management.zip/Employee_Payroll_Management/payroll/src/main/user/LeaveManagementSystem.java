package payroll.src.main.user;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.*;
import payroll.src.main.user.EmployeeSystem;

public class LeaveManagementSystem {

    // Employee class to store leave information
    static class Employee {
        String name;
        int defaultLeaves = 20;
        int leavesTaken = 0;
        Map<String, Integer> leaveTypes = new HashMap<>();
        Map<String, Integer> appliedLeavesByType = new HashMap<>();

        Employee(String name) {
            this.name = name;
            leaveTypes.put("Casual Leave", 10);
            leaveTypes.put("Sick Leave", 5);
            leaveTypes.put("Other Leave", 5);
            appliedLeavesByType.put("Casual Leave", 0);
            appliedLeavesByType.put("Sick Leave", 0);
            appliedLeavesByType.put("Other Leave", 0);
        }

        int getLeaveBalance() {
            return defaultLeaves - leavesTaken;
        }
    }

    static Map<String, Employee> employees = new HashMap<>();
    static Set<LocalDate> leaveDates = new HashSet<>();
    static final int TERMINAL_WIDTH = 80; // Assumed terminal width for centering

    public static void ApplyForLeave(String[] args) {
        Scanner scanner = new Scanner(System.in);
        printHeader("Welcome to the Leave Management System");
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        employees.putIfAbsent(name, new Employee(name));
        Employee currentEmployee = employees.get(name);

        while (true) {
            printHeader("Main Menu");
            System.out.println("1. Show Leave Summary");
            System.out.println("2. Apply for Leave");
            System.out.println("3. View Calendar");
            System.out.println("4. Check Status for Applied Leaves");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = getIntInput(scanner);

            switch (choice) {
                case 1:
                    showLeaveSummary(currentEmployee);
                    break;
                case 2:
                    applyForLeave(scanner, currentEmployee);
                    break;
                case 3:
                    displayCalendar();
                    break;
                case 4:
                    checkAppliedLeaveStatus(currentEmployee);
                    break;
                case 5:
                    EmployeeSystem.showUserAdminMenu(scanner);
                    printHeader("Exiting the System. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    static void showLeaveSummary(Employee employee) {
        printHeader("Leave Summary for " + employee.name);
        System.out.println("Default Leaves : " + employee.defaultLeaves);
        System.out.println("Leaves Taken   : " + employee.leavesTaken);
        System.out.println("Leave Balance  : " + employee.getLeaveBalance());
        System.out.println("\nLeave Types and Balances:");
        for (Map.Entry<String, Integer> entry : employee.leaveTypes.entrySet()) {
            System.out.printf("  %s: %d%n", entry.getKey(), entry.getValue());
        }
        printFooter();
    }

    static void applyForLeave(Scanner scanner, Employee employee) {
        while (true) {
            printHeader("Leave Application");
            System.out.print("Enter date for leave (yyyy-mm-dd): ");
            String dateInput = scanner.next();
            LocalDate leaveDate;

            try {
                leaveDate = LocalDate.parse(dateInput);

                if (leaveDate.isBefore(LocalDate.now())) {
                    System.out.println("Leave cannot be applied for past dates. Try again.");
                    continue;
                }

                System.out.println("\nLeave Types Available:");
                int index = 1;
                for (String type : employee.leaveTypes.keySet()) {
                    System.out.println(index++ + ". " + type);
                }
                System.out.print("Choose leave type: ");
                int leaveTypeChoice = getIntInput(scanner);

                if (leaveTypeChoice < 1 || leaveTypeChoice > employee.leaveTypes.size()) {
                    System.out.println("Invalid leave type selection. Please try again.");
                    continue;
                }

                String leaveType = (String) employee.leaveTypes.keySet().toArray()[leaveTypeChoice - 1];

                // Restrict sick leave to today, tomorrow, or the day after tomorrow
                if ("Sick Leave".equals(leaveType)) {
                    LocalDate today = LocalDate.now();
                    LocalDate tomorrow = today.plusDays(1);
                    LocalDate dayAfterTomorrow = today.plusDays(2);

                    if (!leaveDate.equals(today) && !leaveDate.equals(tomorrow)
                            && !leaveDate.equals(dayAfterTomorrow)) {
                        System.out.println(
                                "Warning: Sick leave can only be applied for today, tomorrow, or the day after tomorrow!!!");
                        continue;
                    }
                }

                if (employee.leaveTypes.get(leaveType) > 0) {
                    employee.leaveTypes.put(leaveType, employee.leaveTypes.get(leaveType) - 1);
                    employee.appliedLeavesByType.put(leaveType, employee.appliedLeavesByType.get(leaveType) + 1);
                    employee.leavesTaken++;
                    leaveDates.add(leaveDate);
                    System.out.println("Leave applied successfully for " + leaveDate + " as " + leaveType
                            + " , waiting for approval from respective HR/Manager!!!");
                } else {
                    System.out.println("Insufficient leave balance for " + leaveType);
                }
                printFooter();
                return; // Exit leave application
            } catch (Exception e) {
                System.out.println("Invalid date format. Please enter a valid date in yyyy-mm-dd format.");
            }
        }
    }

    static void checkAppliedLeaveStatus(Employee employee) {
        printHeader("Status of Applied Leaves for " + employee.name);
        System.out.println("Total Leaves Applied (Pending Approval): " + employee.leavesTaken);
        System.out.println("\nBreakdown by Leave Type (Pending Approval):");

        boolean hasLeaves = false; // Track if any leave type has been applied
        for (Map.Entry<String, Integer> entry : employee.appliedLeavesByType.entrySet()) {
            if (entry.getValue() > 0) {
                System.out.printf("  %s: %d (Pending)%n", entry.getKey(), entry.getValue());
                hasLeaves = true;
            }
        }

        if (!hasLeaves) {
            System.out.println("No leaves are pending for approval.");
        }

        printFooter();
    }

    static void displayCalendar() {
        printHeader("Calendar View (Next 3 Months)");
        LocalDate today = LocalDate.now();
        int currentYear = today.getYear();
        int currentMonth = today.getMonthValue();

        for (int i = 0; i < 3; i++) {
            int month = (currentMonth + i - 1) % 12 + 1;
            int year = currentYear + (currentMonth + i - 1) / 12;
            YearMonth yearMonth = YearMonth.of(year, month);

            System.out.println("\n" + yearMonth.getMonth() + " " + yearMonth.getYear());
            System.out.println("Su Mo Tu We Th Fr Sa");
            LocalDate firstDay = yearMonth.atDay(1);
            int dayOfWeek = firstDay.getDayOfWeek().getValue() % 7;

            for (int j = 0; j < dayOfWeek; j++) {
                System.out.print("   ");
            }

            for (int day = 1; day <= yearMonth.lengthOfMonth(); day++) {
                LocalDate date = yearMonth.atDay(day);
                String color;

                if (date.getDayOfWeek().getValue() >= 6) {
                    color = "\033[0;37m"; // White for weekends
                } else if (date.isBefore(today)) {
                    color = "\033[0;32m"; // Green for past days (present)
                } else if (leaveDates.contains(date)) {
                    color = "\033[0;34m"; // Blue for leaves
                } else {
                    color = "\033[0;90m"; // Gray for future dates
                }
                System.out.printf(color + "%2d " + "\033[0m", day);

                if ((day + dayOfWeek) % 7 == 0) {
                    System.out.println();
                }
            }
            System.out.println();
        }
        printFooter();
    }

    static void printHeader(String title) {
        int titleLength = title.length();
        int padding = (TERMINAL_WIDTH - titleLength - 15) / 2; // Adjust padding for company name and time

        String border = "=".repeat(TERMINAL_WIDTH);
        String companyName = "Amdocs";
        String currentTime = LocalTime.now().toString().substring(0, 5); // Format to HH:mm

        String paddedTitle = " ".repeat(padding) + title + "  |  " + companyName + "  |  " + currentTime;

        System.out.println("\n" + border);
        System.out.println(paddedTitle);
        System.out.println(border);
    }

    static void printFooter() {
        System.out.println("=".repeat(TERMINAL_WIDTH));
    }

    static int getIntInput(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.next(); // Consume invalid input
        }
        return scanner.nextInt();
    }
}
