package payroll.src.main.user;

import java.util.Calendar;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import payroll.src.main.user.AM;
import payroll.src.main.user.LeaveManagementSystem;
import payroll.src.main.user.PaySlip;

public class EmployeeSystem {

    private static final HashMap<String, String> userDatabase = new HashMap<>();

    static {
        // Example user database
        userDatabase.put("12345", "Admin@123");
        userDatabase.put("67890", "User@456");
    }

    public static void handleLogin(Scanner scanner) {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("       Welcome To  Amdocs!!!     ");
        System.out.println("             User Login          ");
        System.out.println("=".repeat(40));

        while (true) {
            try {
                System.out.print("Enter EmpID (5 digits): ");
                String empId = scanner.nextLine().trim();

                // Validate EmpID
                if (!empId.matches("^[0-9]{1,5}$")) {
                    throw new IllegalArgumentException(
                            "Invalid Employee ID! It must be numeric and between 1 to 5 digits.");
                }

                if (empId.length() != 5) {
                    throw new IllegalArgumentException("Employee ID must be exactly 5 characters long!");
                }
                if (!empId.matches("\\d+")) {
                    throw new IllegalArgumentException("Employee ID must contain only numeric digits!");
                }
                System.out.print("Enter Password: ");
                String password = scanner.nextLine().trim();

                // Validate password format
                if (!isValidLoginPassword(password)) {
                    System.out.println("Invalid password format. Password must be alphanumeric and contain:");
                    System.out.println("1. At least one uppercase letter.");
                    System.out.println("2. At least one lowercase letter.");
                    System.out.println("3. At least one special character (e.g., @, #, $, %, ^).");
                    continue;
                }

                // Validate credentials
                if (isValidLogin(empId, password)) {
                    System.out.println("\nLogin successful! Welcome, User.");
                    showUserAdminMenu(scanner);
                    break;
                } else {
                    System.out.println("Invalid Employee ID or Password. Please try again.");
                }

            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }

    // Validate login credentials
    private static boolean isValidLogin(String empId, String password) {
        return userDatabase.containsKey(empId) && userDatabase.get(empId).equals(password);
    }

    // Validate the login password format (alphanumeric, special character, etc.)
    private static boolean isValidLoginPassword(String password) {
        // Password must be alphanumeric, contain at least one uppercase, one lowercase,
        // and one special character
        String passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>])[A-Za-z\\d!@#$%^&*(),.?\":{}|<>]{8,}$";
        return password.matches(passwordPattern);
    }

    public static void showUserAdminMenu(Scanner scanner) {
        String empId = "12345"; // Hardcoded for simplicity
        String name = "John Doe";
        String designation = "Software Engineer";
        String department = "IT";
        String joiningDate = "01/01/2020";

        while (true) {
            System.out.println("\n========== User Menu ==========");
            System.out.println("Please choose an option:");
            System.out.println("1. View Employee Details");
            System.out.println("2. Update Password");
            System.out.println("3. View Pay Slip");
            System.out.println("4. Mark Attendance");
            System.out.println("5. Leave Management Details");
            System.out.println("6. Logout");
            System.out.println("=".repeat(40));

            // Keep the input prompt on the same line
            System.out.print("Enter your choice (1-6): ");
            String input = scanner.nextLine(); // User input captured here

            System.out.println("=".repeat(40));

            try {
                int choice = Integer.parseInt(input);
                switch (choice) {
                    case 1:
                        System.out.printf("%-25s : %s%n", "Employee ID", empId);
                        System.out.printf("%-25s : %s%n", "Name", name);
                        System.out.printf("%-25s : %s%n", "Designation", designation);
                        System.out.printf("%-25s : %s%n", "Department", department);
                        System.out.printf("%-25s : %s%n", "Joining Date", joiningDate);
                        break;
                    case 2:
                        updatePassword(scanner, empId);
                        return;
                    case 3:
                        PaySlip.ViewPaySlip(new String[] {}, scanner);
                        return;
                    case 4:
                        AM.AttendanceManagement(new String[] {});
                        return;
                    case 5:
                        LeaveManagementSystem.ApplyForLeave(new String[] {});
                        return;
                    case 6:
                        logout();
                        return;
                    default:
                        System.out.println("Invalid input! Please select a valid option (1-6).");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number (1-6).");
            }
        }
    }

    private static void logout() {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("You have logged out successfully.");
        System.out.println("=".repeat(40));
    }

    // Method for updating the password
    private static void updatePassword(Scanner scanner, String empId) {
        String oldPassword = "";
        boolean isPasswordUpdated = false;
        int attempts = 0; // Track the number of attempts for the old password

        while (attempts < 3 && !isPasswordUpdated) {
            System.out.print("Enter your old password: ");
            oldPassword = scanner.nextLine();

            // Check if the entered old password is correct
            if (!userDatabase.get(empId).equals(oldPassword)) {
                attempts++;
                System.out.println("Incorrect old password.");
                System.out.println("You have " + (3 - attempts) + " attempt(s) left.");
                if (attempts >= 3) {
                    System.out.println("You have reached the maximum number of attempts!!! Login again.");
                    logout();
                    return; // Exit to the login screen after 3 failed attempts
                }
            } else {
                break; // Proceed to update the password if old password is correct
            }
        }

        if (attempts < 3) {
            int newPasswordAttempts = 0; // Track attempts for the new password
            String newPassword = "";

            while (newPasswordAttempts < 3 && !isPasswordUpdated) {
                if (newPasswordAttempts == 0) {
                    System.out.println("Hint: Your new password must:");
                    System.out.println("1. Be at least 8 characters long.");
                    System.out.println("2. Contain at least one uppercase letter.");
                    System.out.println("3. Contain at least one lowercase letter.");
                    System.out.println("4. Contain at least one special character (e.g., @, #, $, %, ^).");
                }

                System.out.print("Enter your new password: ");
                newPassword = scanner.nextLine();

                if (!isValidPassword(newPassword)) {
                    System.out.println("New password is invalid.");
                    newPasswordAttempts++;
                    System.out.println("You have " + (3 - newPasswordAttempts) + " attempt(s) left.");
                    if (newPasswordAttempts >= 3) {
                        System.out.println("You have reached the maximum number of attempts!!! Login again.");
                        logout();
                        return; // Exit to the login screen after 3 failed attempts
                    }
                } else {
                    if (newPassword.equals(oldPassword)) {
                        System.out.println("New password cannot be the same as the old password.");
                        newPasswordAttempts++;
                        System.out.println("You have " + (3 - newPasswordAttempts) + " attempt(s) left.");
                        if (newPasswordAttempts >= 3) {
                            System.out.println("You have reached the maximum number of attempts!!! Login again.");
                            logout();
                            return;
                        }
                    } else {
                        System.out.print("Re-enter your new password: ");
                        String reenteredPassword = scanner.nextLine();

                        if (!newPassword.equals(reenteredPassword)) {
                            System.out.println("New passwords do not match.");
                            newPasswordAttempts++;
                            System.out.println("You have " + (3 - newPasswordAttempts) + " attempt(s) left.");
                            if (newPasswordAttempts >= 3) {
                                System.out.println("You have reached the maximum number of attempts!!! Login again.");
                                logout();
                                return;
                            }
                        } else {
                            userDatabase.put(empId, newPassword);
                            System.out.println("Your password has been successfully updated!");
                            isPasswordUpdated = true; // Exit the loop after successful password update
                        }
                    }

                }
            }
        }

        if (isPasswordUpdated) {
            logout(); // Redirect to login after successful update
        }
    }

    // Method to validate the new password
    private static boolean isValidPassword(String password) {
        String passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>])[A-Za-z\\d!@#$%^&*(),.?\":{}|<>]{8,}$";
        return password.matches(passwordPattern);
    }

    // View Pay SLip

}
