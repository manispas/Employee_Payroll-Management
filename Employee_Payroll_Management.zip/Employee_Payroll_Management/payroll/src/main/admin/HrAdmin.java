package payroll.src.main.admin;

import java.util.*;

public class HrAdmin {

    private static final String DB_ADMIN_USERNAME = "adminDB";
    private static final String DB_ADMIN_PASSWORD = "password123";

    // Dummy leave request data
    private static List<LeaveRequest> leaveRequests = new ArrayList<>();

    // Dummy attendance records
    private static Map<String, List<AttendanceRecord>> attendanceRecords = new HashMap<>();

    public static void handleLogin(Scanner scanner) {
       
        leaveRequests.add(new LeaveRequest("67890", "Manish Kumar", "Support", "2024-11-20", "Medical Emergency", "Sick Leave",
                "Pending"));
        leaveRequests
                .add(new LeaveRequest("10001", "Abhinav Singh", "AT Mobile", "2024-11-30", "Vacation", "Other Leave", "Pending"));
        leaveRequests.add(new LeaveRequest("12345", "Arham Jain", "PSU BSS", "2024-11-30", "Medical Emergency", "Sick Leave",
                "Pending"));
        leaveRequests
                .add(new LeaveRequest("12345", "Arham Jain", "PSU BSS", "2024-11-29", "Vacation", "Casual Leave", "Pending"));
             
            
               
            
           
        // Dummy attendance records
        List<AttendanceRecord> records1 = Arrays.asList(
                new AttendanceRecord("2024-11-18", "Present", "09:00", "17:00", 8),
                new AttendanceRecord("2024-11-19", "Present", "10:00", "17:00", 7),
                new AttendanceRecord("2024-11-20", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-21", "Present", "09:00", "17:00", 8),
                new AttendanceRecord("2024-11-22", "Present", "09:00", "17:00", 7),
                new AttendanceRecord("2024-11-25", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-26", "Present", "09:00", "17:00", 8),
                new AttendanceRecord("2024-11-27", "Present", "09:00", "17:00", 7),
                new AttendanceRecord("2024-11-28", "Absent", null, null, 0)
                );
                
        attendanceRecords.put("12345", records1);

        List<AttendanceRecord> records2 = Arrays.asList(
                new AttendanceRecord("2024-11-15", "Present", "08:00", "17:00", 9),
                new AttendanceRecord("2024-11-14", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-13", "Present", "09:00", "17:00", 8),
                new AttendanceRecord("2024-11-12", "Present", "08:00", "17:00", 9),
                new AttendanceRecord("2024-11-11", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-18", "Present", "09:00", "17:00", 7),
                new AttendanceRecord("2024-11-19", "Present", "08:00", "17:00", 9),
                new AttendanceRecord("2024-11-20", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-21", "Present", "09:00", "17:00", 7),
                new AttendanceRecord("2024-11-22", "Present", "08:00", "17:00", 9),
                new AttendanceRecord("2024-11-25", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-26", "Present", "09:00", "17:00", 7),
                new AttendanceRecord("2024-11-27", "Present", "08:00", "17:00", 9),
                new AttendanceRecord("2024-11-28", "Absent", null, null, 0),
                new AttendanceRecord("2024-11-29", "Present", "09:00", "17:00", 7)

                );
        attendanceRecords.put("67890", records2);

        List<AttendanceRecord> records3 = Arrays.asList(
            new AttendanceRecord("2024-11-15", "Present", "08:00", "17:00", 9),
            new AttendanceRecord("2024-11-14", "Absent", null, null, 0),
            new AttendanceRecord("2024-11-13", "Present", "09:00", "17:00", 7),
            new AttendanceRecord("2024-11-12", "Present", "08:00", "17:00", 9),
            new AttendanceRecord("2024-11-11", "Absent", null, null, 0),
            new AttendanceRecord("2024-11-18", "Present", "09:00", "17:00", 7),
            new AttendanceRecord("2024-11-19", "Present", "08:00", "17:00", 9),
            new AttendanceRecord("2024-11-20", "Absent", null, null, 0),
            new AttendanceRecord("2024-11-21", "Present", "09:00", "17:00", 7),
            new AttendanceRecord("2024-11-22", "Present", "08:00", "17:00", 9),
            new AttendanceRecord("2024-11-25", "Absent", null, null, 0),
            new AttendanceRecord("2024-11-26", "Present", "09:00", "17:00", 7),
            new AttendanceRecord("2024-11-27", "Present", "08:00", "17:00", 9),
            new AttendanceRecord("2024-11-28", "Absent", null, null, 0),
            new AttendanceRecord("2024-11-29", "Present", "09:00", "17:00", 7)
 
            );
    attendanceRecords.put("10001", records3);
        System.out.println("\n========== HR Administrator Login ==========");

        while (true) {
            try {
                System.out.print("Enter Username: ");
                String username = scanner.nextLine().trim();

                if (username.isEmpty()) {
                    throw new IllegalArgumentException("Username cannot be empty!");
                }

                System.out.print("Enter Password: ");
                String password = scanner.nextLine().trim();

                if (password.isEmpty()) {
                    throw new IllegalArgumentException("Password cannot be empty!");
                }

                if (username.equals(DB_ADMIN_USERNAME) && password.equals(DB_ADMIN_PASSWORD)) {
                    System.out.println("\nLogin successful! Welcome, Database Administrator.");
                    showAdminMenu(scanner);
                    break;
                } else {
                    System.out.println("Invalid username or password. Please try again.\n");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println("Please re-enter your credentials.\n");
            }
        }
    }

    public static void showAdminMenu(Scanner scanner) {
        while (true) {

            System.out.println("\n========== HR Administrator Menu ==========");
            System.out.println("1. View and Manage Leave Requests");
            System.out.println("2. View Attendance Records");
            System.out.println("3. Logout");
            System.out.print("Select an option (1-3): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        manageLeaveRequests(scanner);
                        break;
                    case 2:
                        viewAttendanceRecords(scanner);
                        break;
                    case 3:
                        System.out.println("Logging out...");
                        return;
                    default:
                        System.out.println("Invalid input! Please select a valid option (1-3).");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number (1-3).");
            }
        }
    }

    private static void manageLeaveRequests(Scanner scanner) {
        System.out.println("\n========== Pending Leave Requests ==========");
        if (leaveRequests.isEmpty()) {
            System.out.println("No pending leave requests at the moment.");
        } else {
            System.out.printf("%-10s | %-20s | %-15s | %-20s | %-10s | %-10s | %-10s\n",
                    "Emp ID", "Name", "Department", "Leave Date", "Reason", "Type", "Status");
            System.out
                    .println("---------------------------------------------------------------------------------------");
            for (LeaveRequest request : leaveRequests) {
                System.out.printf("%-10s | %-20s | %-15s | %-20s | %-10s | %-10s | %-10s\n",
                        request.getEmpId(), request.getName(), request.getDepartment(),
                        request.getLeaveDate(), request.getReason(), request.getType(), request.getStatus());
            }

            boolean validInput = false;
            while (!validInput) {
                System.out.print("\nDo you want to update a leave request? (y/n): ");
                String update = scanner.nextLine().trim().toLowerCase();
                if (update.equals("y") || update.equals("n")) {
                    validInput = true;
                    if (update.equals("y")) {
                        handleUpdateLeaveRequest(scanner);
                    }
                } else {
                    System.out.println("Invalid input! Please enter 'y' for yes or 'n' for no.");
                }
            }
        }
    }

    private static void handleUpdateLeaveRequest(Scanner scanner) {
        boolean empIdValid = false;
        while (!empIdValid) {
            System.out.print("Enter the Employee ID for the leave request to update: ");
            String empId = scanner.nextLine().trim();
            boolean found = false;

            for (LeaveRequest request : leaveRequests) {
                if (request.getEmpId().equals(empId) && request.getStatus().equalsIgnoreCase("Pending")) {
                    found = true;
                    empIdValid = true;

                    boolean decisionValid = false;
                    while (!decisionValid) {
                        System.out.print("Approve (a) or Reject (r) this request? ");
                        String decision = scanner.nextLine().trim().toLowerCase();
                        if (decision.equals("a")) {
                            request.setStatus("Approved");
                            System.out.println("Leave request approved.");
                            decisionValid = true;
                        } else if (decision.equals("r")) {
                            request.setStatus("Rejected");
                            System.out.println("Leave request rejected.");
                            decisionValid = true;
                        } else {
                            System.out.println("Invalid input! Please enter 'a' to approve or 'r' to reject.");
                        }
                    }
                    break;
                }
            }
            if (!found) {
                System.out.println("No matching pending leave request found for Employee ID: " + empId + "\n");
                System.out.println("Please try again or enter a valid Employee ID.\n");
            }
        }
    }

    private static void viewAttendanceRecords(Scanner scanner) {
        System.out.println("\n========== Attendance Records ==========");

        String empId;
        while (true) {
            try {
                System.out.print("Enter Employee ID to view attendance: ");
                empId = scanner.nextLine().trim();

                // Validate input (e.g., numeric check for Employee ID)
                if (empId.isEmpty()) {
                    throw new IllegalArgumentException("Employee ID cannot be empty. Please try again.");
                }
                if (!empId.matches("\\d+")) { // Assuming Employee IDs are numeric
                    throw new IllegalArgumentException("Employee ID must contain only digits. Please try again.");
                }

                // If Employee ID exists in attendance records
                if (!attendanceRecords.containsKey(empId)) {
                    System.out.println("No attendance records found for Employee ID: " + empId);
                } else {
                    // Fetch and display attendance records
                    List<AttendanceRecord> records = attendanceRecords.get(empId);
                    System.out.printf("%-15s | %-10s | %-15s | %-15s | %-10s\n",
                            "Date", "Status", "Clock In", "Clock Out", "Hours Worked");
                    System.out.println("-------------------------------------------------------------------");

                    double totalHours = 0;
                    for (AttendanceRecord record : records) {
                        System.out.printf("%-15s | %-10s | %-15s | %-15s | %-10.2f\n",
                                record.getDate(), record.getStatus(),
                                record.getClockIn(), record.getClockOut(), record.getHoursWorked());
                        totalHours += record.getHoursWorked();
                    }
                    System.out.printf("\nTotal Hours Worked by Employee %s: %.2f\n", empId, totalHours);
                }
                break; // Exit loop if input is valid and processed
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred. Please try again.");
            }
        }
    }

    public static void addDummyData() {
        // Dummy leave requests

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Add dummy data
        addDummyData();

        // Start login process
        handleLogin(scanner);
    }
}

// Leave Request Class
class LeaveRequest {
    private String empId, name, department, leaveDate, reason, type, status;

    public LeaveRequest(String empId, String name, String department, String leaveDate, String reason, String type,
            String status) {
        this.empId = empId;
        this.name = name;
        this.department = department;
        this.leaveDate = leaveDate;
        this.reason = reason;
        this.type = type;
        this.status = status;
    }

    public String getEmpId() {
        return empId;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getLeaveDate() {
        return leaveDate;
    }

    public String getReason() {
        return reason;
    }

    public String getType() {
        return type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

// Attendance Record Class
class AttendanceRecord {
    private String date, status, clockIn, clockOut;
    private double hoursWorked;

    public AttendanceRecord(String date, String status, String clockIn, String clockOut, double hoursWorked) {
        this.date = date;
        this.status = status;
        this.clockIn = clockIn;
        this.clockOut = clockOut;
        this.hoursWorked = hoursWorked;
    }

    public String getDate() {
        return date;
    }

    public String getStatus() {
        return status;
    }

    public String getClockIn() {
        return clockIn;
    }

    public String getClockOut() {
        return clockOut;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }
}
