package payroll.src.main.admin;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.Collectors;

public class DatabaseAdmin {
    // private static final String DB_ADMIN_USERNAME = "adminDB";
    // private static final String DB_ADMIN_PASSWORD = "password123";

    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String USER = "system";
    private static final String PASS = "Anshul@12345";

    public static void handleLogin(Scanner scanner) {
        System.out.println("\n========== Database Administrator Login ==========");
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();

        // Check if username is empty
        if (username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty!");
        }

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // Check if password is empty
        if (password.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty!");
        }
    
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
    
        try {
            // Load Oracle JDBC driver
            Class.forName("oracle.jdbc.OracleDriver");
    
            // Establish connection to the database
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
    
            // Prepare SQL query to search for the username
            String sql = "SELECT password FROM admin_passwords WHERE username = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);  // Set the username parameter
    
            // Execute the query
            rs = pstmt.executeQuery();
    
            // Check if the username exists and validate the password
            if (rs.next()) {
                String storedPassword = rs.getString("password");  // Get the stored password
    
                // Validate the password
                if (storedPassword.equals(password)) {
                    System.out.println("Login successful! Welcome, Database Administrator.\n");
                    showAdminMenu(scanner);  // Proceed to admin menu
                } else {
                    System.out.println("Incorrect password. Returning to main menu.\n");
                }
            } else {
                // Username not found in the table
                System.out.println("Username not found. Returning to main menu.\n");
            }
    
        } catch (ClassNotFoundException e) {
            System.out.println("Oracle JDBC driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection error.");
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    private static void showAdminMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n========== Database Administrator Menu ==========");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employee Details");
            System.out.println("3. Update Employee Details");
            System.out.println("4. Delete Employee");
            System.out.println("5. Logout\n");
            System.out.print("Select an option (1-5): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        addEmployee(scanner);
                        break;
                    case 2:
                        viewEmployeeDetails(scanner);
                        break;
                    case 3:
                        updateEmployeeDetails(scanner);
                        break;
                    case 4:
                        deleteEmployee(scanner);
                        break;
                    case 5:
                        System.out.println("Logging out...");
                        return;
                    default:
                        System.out.println("Invalid input! Please select a valid option (1-5).");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number (1-5).");
            }
        }
    }

    private static void addEmployee(Scanner scanner) {
        System.out.println("\n========== Add Employee ==========");

        int empId = getValidEmployeeId(scanner);
        String empFname = getValidName(scanner, "First Name");
        String empLname = getValidName(scanner, "Last Name");
        String designation = getValidTextInput(scanner, "Designation");
        String dept = getValidTextInput(scanner, "Department");
        LocalDate joiningDate = getValidDate(scanner);
        double salary = getValidSalary(scanner);

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            String sqlEmployee = "INSERT INTO employee (emp_id, emp_fname, emp_lname, designation, dept, joining_date, salary) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlEmployee)) {
                pstmt.setInt(1, empId);
                pstmt.setString(2, empFname);
                pstmt.setString(3, empLname);
                pstmt.setString(4, designation);
                pstmt.setString(5, dept);
                pstmt.setDate(6, java.sql.Date.valueOf(joiningDate));
                pstmt.setDouble(7, salary);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Employee added to the employee table successfully!");
                } else {
                    System.out.println("Failed to add employee to the employee table.");
                }
            }

            String username = generateUsername(empFname, empId);
            String password = generatePassword();

            String sqlPassword = "INSERT INTO generated_password (emp_id, fname, lname, designation, dept, joining_date, salary, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlPassword)) {
                pstmt.setInt(1, empId);
                pstmt.setString(2, empFname);
                pstmt.setString(3, empLname);
                pstmt.setString(4, designation);
                pstmt.setString(5, dept);
                pstmt.setDate(6, java.sql.Date.valueOf(joiningDate));
                pstmt.setDouble(7, salary);
                pstmt.setString(8, username);
                pstmt.setString(9, password);

                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Employee credentials added successfully!");
                    System.out.println("Username: " + username);
                    System.out.println("Password: " + password);
                } else {
                    System.out.println("Failed to add employee credentials.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error while adding employee: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static int getValidEmployeeId(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Enter Employee ID (5 digits): ");
                String input = scanner.nextLine();
                if (input.matches("\\d{5}")) {
                    return Integer.parseInt(input);
                } else {
                    throw new IllegalArgumentException("Employee ID must be exactly 5 digits.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static String getValidName(Scanner scanner, String fieldName) {
        while (true) {
            try {
                System.out.print("Enter " + fieldName + ": ");
                String input = scanner.nextLine().trim();
                if (input.matches("[a-zA-Z]+")) {
                    return input;
                } else {
                    throw new IllegalArgumentException(fieldName + " must contain only alphabetic characters.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static String getValidTextInput(Scanner scanner, String fieldName) {
        while (true) {
            try {
                System.out.print("Enter " + fieldName + ": ");
                String input = scanner.nextLine().trim();
                if (!input.isEmpty()) {
                    return input;
                } else {
                    throw new IllegalArgumentException(fieldName + " cannot be empty.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static LocalDate getValidDate(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Enter Joining Date (YYYY-MM-DD): ");
                String input = scanner.nextLine();
                return LocalDate.parse(input, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            } catch (DateTimeParseException e) {
                System.out.println("Error: Invalid date format. Please use YYYY-MM-DD.");
            }
        }
    }

    private static double getValidSalary(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Enter Salary: ");
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Salary must be a numeric value.");
            }
        }
    }

    private static String generateUsername(String firstName, int empId) {
        String empIdStr = String.valueOf(empId);
        return firstName.substring(0, Math.min(3, firstName.length())) + empIdStr.substring(empIdStr.length() - 3);
    }

    private static String generatePassword() {
        String charPool = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
        Random random = new Random();
        return random.ints(8, 0, charPool.length())
                     .mapToObj(charPool::charAt)
                     .map(String::valueOf)
                     .collect(Collectors.joining());
    }
    private static void viewEmployeeDetails(Scanner scanner) {
        System.out.println("\n========== View Employee Details ==========");
        System.out.print("Enter Employee ID to view details: ");
        int empId = Integer.parseInt(scanner.nextLine());

        String sql = "SELECT * FROM employee WHERE emp_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Employee ID: " + rs.getInt("emp_id"));
                    System.out.println("First Name: " + rs.getString("emp_fname"));
                    System.out.println("Last Name: " + rs.getString("emp_lname"));
                    System.out.println("Designation: " + rs.getString("designation"));
                    System.out.println("Department: " + rs.getString("dept"));
                    System.out.println("Joining Date: " + rs.getDate("joining_date"));
                    System.out.println("Salary: " + rs.getDouble("salary"));
                } else {
                    System.out.println("Employee not found!");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateEmployeeDetails(Scanner scanner) {
        System.out.println("\n========== Update Employee Details ==========");
        System.out.print("Enter Employee ID to update: ");
        int empId = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter New First Name : ");
        String empFname = scanner.nextLine();

        System.out.print("Enter New Last Name : ");
        String empLname = scanner.nextLine();

        System.out.print("Enter New Designation : ");
        String designation = scanner.nextLine();

        System.out.print("Enter New Department : ");
        String dept = scanner.nextLine();

        System.out.print("Enter New Salary : ");
        String salaryInput = scanner.nextLine();
        Double salary = salaryInput.isEmpty() ? null : Double.parseDouble(salaryInput);

        String sql = "UPDATE employee SET emp_fname = NVL(?, emp_fname), emp_lname = NVL(?, emp_lname), " +
                     "designation = NVL(?, designation), dept = NVL(?, dept), salary = NVL(?, salary) WHERE emp_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, empFname.isEmpty() ? null : empFname);
            pstmt.setString(2, empLname.isEmpty() ? null : empLname);
            pstmt.setString(3, designation.isEmpty() ? null : designation);
            pstmt.setString(4, dept.isEmpty() ? null : dept);
            if (salary == null) pstmt.setNull(5, Types.DOUBLE); else pstmt.setDouble(5, salary);
            pstmt.setInt(6, empId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee details updated successfully!");
            } else {
                System.out.println("Failed to update employee.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        String sql2 = "UPDATE generated_password SET fname = NVL(?, emp_fname), lname = NVL(?, emp_lname), " +
                     "designation = NVL(?, designation), dept = NVL(?, dept), salary = NVL(?, salary) WHERE emp_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql2)) {

            pstmt.setString(1, empFname.isEmpty() ? null : empFname);
            pstmt.setString(2, empLname.isEmpty() ? null : empLname);
            pstmt.setString(3, designation.isEmpty() ? null : designation);
            pstmt.setString(4, dept.isEmpty() ? null : dept);
            if (salary == null) pstmt.setNull(5, Types.DOUBLE); else pstmt.setDouble(5, salary);
            pstmt.setInt(6, empId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee details updated successfully!");
            } else {
                System.out.println("Failed to update employee.");
            }
        } catch (Exception e) {
            // System.out.println("Error: " + e.getMessage());
        }


        
    }

    private static void deleteEmployee(Scanner scanner) {
        System.out.println("\n========== Delete Employee ==========");
        System.out.print("Enter Employee ID to delete: ");
        int empId = Integer.parseInt(scanner.nextLine());
    
        String deleteEmployeeSql = "DELETE FROM employee WHERE emp_id = ?";
    
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            // Delete from `employee` table
            try (PreparedStatement pstmt = conn.prepareStatement(deleteEmployeeSql)) {
                pstmt.setInt(1, empId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    // System.out.println("Employee deleted successfully from the `employee` table.");
                } else {
                    System.out.println("Employee not found in the `employee` table.");
                }
            }
    
            // Delete from `generated_password` table
            String deletePasswordSql = "DELETE FROM generated_password WHERE emp_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deletePasswordSql)) {
                pstmt.setInt(1, empId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Employee credentials deleted successfully!!!");
                } else {
                    System.out.println("Employee not found in the `generated_password` table.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error while deleting employee: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
}
