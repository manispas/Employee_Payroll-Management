package payroll.src.main.admin;

import java.util.Scanner;

public class PayrollAdmin {

    private static final String DB_ADMIN_USERNAME = "adminDB";
    private static final String DB_ADMIN_PASSWORD = "password123";
    private static final double MIN_INCENTIVE_PERCENT = 3.0;
    private static final double MAX_INCENTIVE_PERCENT = 12.0;
    private static final int WORKING_DAYS_YEAR = 270;
    private static final int WORKING_HOURS_DAY = 9;
    private static final int HOURS_THRESHOLD = 10; // Optional for Method 2

    public static void handleLogin(Scanner scanner) {
        System.out.println("\n========== Payroll Administrator Login ==========");
        while (true) {
            try {
                System.out.print("Enter Username: ");
                String username = scanner.nextLine().trim();
                if (username.isEmpty()) throw new IllegalArgumentException("Username cannot be empty!");

                System.out.print("Enter Password: ");
                String password = scanner.nextLine().trim();
                if (password.isEmpty()) throw new IllegalArgumentException("Password cannot be empty!");

                if (username.equals(DB_ADMIN_USERNAME) && password.equals(DB_ADMIN_PASSWORD)) {
                    System.out.println("\nLogin successful! Welcome, Payroll Administrator.");
                    showAdminMenu(scanner);
                    break;
                } else {
                    System.out.println("Invalid username or password. Please try again.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
    }

    private static void showAdminMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n========== Payroll Administrator Menu ==========");
            System.out.println("1. Manage Employee Incentive");
            System.out.println("2. View Pay Slip");
            System.out.println("3. Logout");
            System.out.print("Select an option (1-3): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        manageEmployeeIncentive(scanner);
                        break;
                    case 2:
                        viewPaySlip(scanner);
                        break;
                    case 3:
                        System.out.println("Logging out...");
                        return;
                    default:
                        System.out.println("Invalid input! Please select a valid option (1-3).");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number (1-3).");
            }
        }
    }

    private static void manageEmployeeIncentive(Scanner scanner) {
        System.out.print("\nEnter Employee ID to manage incentive: ");
        String empId = scanner.nextLine();

        // Example dummy data for attendance and base salary
        int workedHours = 200; // Replace with actual hours fetched from attendance records
        double baseSalary = 300_000; // Example base salary

        if (workedHours <= 0 || baseSalary <= 0) {
            System.out.println("Error: Invalid data for employee. Please verify employee records.");
            return;
        }

        // Calculate hourly rate
        double hourlyRate = baseSalary / (WORKING_DAYS_YEAR * WORKING_HOURS_DAY);
        System.out.println("\nEmployee's Base Salary: " + baseSalary);
        System.out.println("Hourly Rate: " + String.format("%.2f", hourlyRate));
        System.out.println("Total Hours Worked: " + workedHours);

        if (workedHours > WORKING_DAYS_YEAR * WORKING_HOURS_DAY) {
            int extraHours = workedHours - (WORKING_DAYS_YEAR * WORKING_HOURS_DAY);
            double incentive = extraHours * hourlyRate;
            System.out.println("Extra Hours: " + extraHours);
            System.out.println("Calculated Incentive: " + String.format("%.2f", incentive));
        } else {
            System.out.println("No extra hours worked. Employee is not eligible for incentives.");
        }
    }

    private static void viewPaySlip(Scanner scanner) {
        System.out.print("\nEnter Employee ID to view Pay Slip: ");
        String empId = scanner.nextLine();

        // Example dummy data
        double baseSalary = 300_000;
        double totalIncentives = 5_000; // Example incentives

        // Generate and display the pay slip
        System.out.println("\n========== Pay Slip ==========");
        System.out.println("Employee ID: " + empId);
        System.out.println("Base Salary: " + baseSalary);
        System.out.println("Incentives: " + totalIncentives);
        System.out.println("Gross Salary: " + (baseSalary + totalIncentives));
        System.out.println("==============================");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        handleLogin(scanner);
    }
}
