package payroll.src.main.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UI {
    private static final String OFFICE_LOCATION = "Amdocs, Sector 21, Gurgaon, Haryana";
   

    public static void displayHeader() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        System.out.println("---------------------------------------------------------");
        System.out.println("                 Employee Payroll Management             ");
        System.out.println("---------------------------------------------------------");
        System.out.println(" Office Location: " + OFFICE_LOCATION);
        System.out.println(" Current Time   : " + timestamp);
        System.out.println("---------------------------------------------------------");
    }

    public static void displayWelcomeMessage() {
        System.out.println("\nWelcome to the Employee Payroll Management System!");
        System.out.println("Efficiently manage employee data, payroll, and much more.\n");
        System.out.println("---------------------------------------------------------");
    }

    public static void displayRoleMenu() {
        System.out.println("\n=========================================================");
        System.out.println("                  Main Menu Options                      ");
        System.out.println("=========================================================");
        System.out.printf("%-20s | %-30s\n", "Role", "Description");
        System.out.println("---------------------------------------------------------");
        System.out.printf("%-20s | %-30s\n", "1. Admin (DB)", "Database Administrator");
        System.out.printf("%-20s | %-30s\n", "2. Admin (HR)", "Leave and Attendance Manager");
     
        System.out.printf("%-20s | %-30s\n", "3. User", "View profile, salary details, and pay slips");
        System.out.printf("%-20s | %-30s\n", "4. Exit", "Exit the application");
        System.out.println("=========================================================");
        System.out.print("Please select your role (1/2/3/4): ");
    }
    
}
